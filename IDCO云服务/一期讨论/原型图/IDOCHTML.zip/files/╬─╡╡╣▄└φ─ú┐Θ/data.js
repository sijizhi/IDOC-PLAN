﻿$axure.loadCurrentPage(
(function() {
    var _ = function() { var r={},a=arguments; for(var i=0; i<a.length; i+=2) r[a[i]]=a[i+1]; return r; }
    var _creator = function() { return _(b,c,d,e,f,g,h,g,i,_(j,k),l,[m,n,o,p,b,q],r,_(s,t,u,v,w,x,y,_(),z,_(A,B,C,D,E,_(F,G,H,I),J,null,K,D,L,D,M,N,O,null,P,Q,R,S,T,U,V,Q),W,_(),X,_(),Y,_(Z,[])),ba,_(),bb,_());}; 
var b="url",c="文档管理模块.html",d="generationDate",e=new Date(1545026695204.52),f="isCanvasEnabled",g=false,h="isAdaptiveEnabled",i="sketchKeys",j="",k="s0",l="variables",m="OnLoadVariable",n="user",o="system_manager",p="File_borrowing_approval",q="valuenn",r="page",s="packageId",t="0fd4a1a002f14d1a83004a60ec11b5ed",u="type",v="Axure:Page",w="name",x="文档管理模块",y="notes",z="style",A="baseStyle",B="627587b6038d43cca051c114ac41ad32",C="pageAlignment",D="near",E="fill",F="fillType",G="solid",H="color",I=0xFFFFFFFF,J="image",K="imageHorizontalAlignment",L="imageVerticalAlignment",M="imageRepeat",N="auto",O="favicon",P="sketchFactor",Q="0",R="colorStyle",S="appliedColor",T="fontName",U="Applied Font",V="borderWidth",W="adaptiveStyles",X="interactionMap",Y="diagram",Z="objects",ba="masters",bb="objectPaths";
return _creator();
})());