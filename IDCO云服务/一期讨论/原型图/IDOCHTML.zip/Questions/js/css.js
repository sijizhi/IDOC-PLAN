

$(document).ready(function(e){
    $(".nano button").hover(function(){
        $(this).css({
            "border":"1px skyblue solid",
            "background":"white"
        })
    },function(){
        $(this).css({
            "border":"1px rgb(186,186,186) solid",
            "background":"rgb(249,249,249)"
        })
    })
})