

$(document).ready(function(e) {
	
	// 文件名编辑 start
	$("#QuestionnaireList").hover(function(){
		$(".operation2").css("display","block");
	},function(){
		$(".operation2").css("display","none");
	})
	
	$(".EditQuestionnaire").click(function(){
		var QuestionnaireName = $(".QuestionnaireName").html();
		$(this).closest(".QuestionnaireList").find(".operation_box").show().html(QuestionnaireName);
		$("[data-toggle='tooltip']").tooltip();
		var question_box = $(this).closest(".question_box");
		var QnName       = question_box.children(".questionElement").find(".QnName").text();
		var Qndescribe   = question_box.children(".questionElement").find(".Qndescribe").text();
		question_box.find(".titleEdit1").text(QnName);
		question_box.find(".titleEdit2").text(Qndescribe);
		//问卷名取消编辑
		$(".cancelEdit").click(function(){
			$(this).closest(".operation_box").empty().hide();
		})
		//问卷名完成编辑
		$(".finishEdit").click(function(){
			question_box.children(".questionElement").find(".QnName").text(question_box.find(".titleEdit1").val());
			question_box.children(".questionElement").find(".Qndescribe").text(question_box.find(".titleEdit2").val());
			$(this).closest(".operation_box").empty().hide();
		})
	})
	// 文件名编辑 end

	//点击添加问题
	$(".nano").on("click",function(e){
		var target = e.target;
		var result = $(target).val();
		if(target.className.indexOf("addRadio") > -1){
			chooseQuestion(result)
		}else if(target.className.indexOf("addCheckbox") > -1){
			chooseQuestion(result)
		}else if(target.className.indexOf("addTian") > -1){
			chooseQuestion(result)
		}else if(target.className.indexOf("addJuChoose") > -1){
			chooseQuestion(result)
		}else if(target.className.indexOf("addDafen") > -1){
			chooseQuestion(result)
		}else if(target.className.indexOf("addJuPing") > -1){
			chooseQuestion(result)
		}
		
	});

	/**
	 * 2018年9月20日17: 19: 53
	 */
	$("#questionList").on("click",function(e){
		var target = e.target;
		if(target.className.indexOf("deleteBox") > -1)
		{
			delecteBox(target);
		}else if(target.className.indexOf("editBox") > -1){//编辑
			//alert("aa");
			editBox(target);
		}else if(target.className.indexOf("addInput")>-1){
			//alert("aa");
			addInput(target);
		}else if(target.className.indexOf("cancelEdit")>-1){//取消编辑
			//alert("aa");
			cancelEdit(target);
		}else if(target.className.indexOf("deleteInput")>-1){//删除选项
			//alert("aa");
			deleteInput(target);
		}else if(target.className.indexOf("finishEdit")>-1){//完成编辑
			finishEdit(target);
			
		}else if(target.className.indexOf("copy")>-1){//复制
			copyBox(target);
			
		}else if(target.className.indexOf("moveup")>-1){//上移
			moveup(target);
			
		}else if(target.className.indexOf("movedown")>-1){//上移
			movedown(target);
			
		}

		
		
	});
	
})

//添加问题公共代码
function o(result){
	//=========================================================
	var question_box    = '<ul class="question_box panel clearboth"  style="min-height:120px;"></ul>';                                   //问题容器盒子 
	var questionElement = '<div class="questionElement" ></div>';                                                                        //存放问题标题和问题内容
	var butName         = "";
	var operation       = '<div class="operation" style="display:none"><a type="button" class="btn btn-primary editBox" >编辑</a>&nbsp;'+
			'<a type="button" class="btn btn-success copy">复制</a>&nbsp;'
			+'<a type="button" class="btn btn-mint luoji">逻辑</a>&nbsp;'
			+'<a type="button" class="deleteBox btn btn-danger" >删除</a></div>';
	//var ranking = $(".questionList").find(".question_box").length+1;  //已有问题个数+1  初始排列置1
	if(result=="1"){//单选
		butName = "【单选】";
	}else if(result=="2"){
		butName = "【多选】";
	}else if(result=="3"){
		butName = "【填空】";
	}else if(result=="4"){
		butName = "【矩阵选择】";
	}else if(result=="5"){
		butName = "【评分题】";
	}else if(result=="6"){
		butName = "【矩阵评分】";
	}
	question_box    = $(question_box).append(operation);
	questionElement = $(questionElement).append('<div class="myTitle"><i class="nmb"></i>. <i class="btwenzi">请编辑问题？</i><span class="butName">'+butName+'</span></div><br/><br/>')
	//标题 	
	if(result=="4"||result=="6"){
		questionElement = $(questionElement).append('<div class="mytable panel hidden"><table class="table table-bordered"><thead></thead><tbody></tbody></table></div>')
	}							
	
	if(result=="3"){
		questionElement = $(questionElement).append('<li><textarea name="" cols="" rows="" class="form-control" ></textarea></li>')
	}
	question_box = $(question_box).append(questionElement);                                                                             //标题放进问题容器里
	question_box = $(question_box).append('<div class="operation_box row" style="background:#F2F2F2" data-t="' + result + '"></div>');  //编辑容器
	//鼠标移动时
	$(question_box).css({
		"border-radius":"10px"
	})
	$(question_box).hover(function() {
		$(this).children(".operation").css("display","block");
		$(this).css({
			 "border": "2px solid #0099ff",
			 "border-radius":"10px"
		});
	 }, function() {
		 $(this).css({
			 "border": "2px solid #fff"  //不在域内的颜色
		 });
		 $(this).children(".operation").css("display","none");
	 });
	return question_box;
	//=========================================================
}

//添加问题
function chooseQuestion(result){
	var question_box = o(result);
	//====================添加问题 初始化给予2个选项 start=====================================
	if(result=="1"||result=="2"||result=="5"){//单选||多选||评分
		for(var inputVal=1;inputVal<3;inputVal++){
			var mathid = Math.floor(Math.random()*100000);
			if(result=="1"){//（单选题）
				var li = '<li class="radio"><input name="a" id="'+mathid+'" data-se="'+inputVal+'" class="magic-radio" type="radio" value="'+mathid+'"><label class="form-label" for="'+mathid+'">选项' + inputVal + '</label></li>';
			}else if(result=="2"){//（多选题）
				var li = '<li class="checkbox"><input name="a" id="'+mathid+'" data-se="'+inputVal+'" class="magic-checkbox" type="checkbox" value="'+mathid+'"><label class="form-label" for="'+mathid+'">选项' + inputVal + '</label></li>';
			}else if(result=="5"){//（打分题）
				var li = '<li class="radio"><input name="a" id="'+mathid+'" data-se="'+inputVal+'" class="magic-radio" type="radio" value="'+mathid+'"><label class="form-label" for="'+mathid+'">' + inputVal + '分</label></li>';
			}
			question_box.children(".questionElement").append(li);
		}
	}else if(result=="4"||result=="6"){//矩阵选择||矩阵评分
		for(var item=0; item<3;item++ ){//遍历行
			
			var tr      = '<tr>'
			var td      = '';
			    td     += '<td data-se="'+item+'">问题' +item+ '</td>';
			var th      = '';
			    th     += '<th data-se="0"></th>';
			var mathid  = Math.floor(Math.random()*100000);
			for(var i = 1; i < 4; i++) { //遍历列
				
				if(item!=0){
					var mathid2  = Math.floor(Math.random()*100000);
					    td      += '<td><li class="radio"><input id="'+mathid2+'"   class="magic-radio"   name="'+mathid+'" type="radio" value=""><label class="form-label" for="'+mathid2+'"></label></li></td>';
				}else{ //选项名
					if(result=="6"){
						th += '<th data-se="'+i+'">'+i+'分</th>';
					}else if(result=="4"){
						th += '<th data-se="'+i+'">选项'+i+'</th>';
					}
				}
			}
			if(item!=0){
				question_box.children(".questionElement").find(".mytable").children("table").children("tbody").append(tr+td);
			}else{
				question_box.children(".questionElement").find(".mytable").children("table").children("thead").append(tr+th);
			}
			question_box.find(".mytable").removeClass("hidden");
			
		}
	}
	
	//=======================添加问题 初始化给予2个选项 end==================================
	
	$(".questionList").append(question_box);//容器装影视盒子
	var len = 0;
	$(".questionList").find(".question_box").each(function(){
		$(".questionList").children(".question_box").eq(len).find(".nmb").text(len+1);
		len++;
	})
	
}




	//删除
	function delecteBox(a){
		//alert("aaa");
		var currentBox = a.parentNode.parentNode;
		currentBox.remove();
		//重排
		var len = 0;
		$(".questionList").find(".question_box").each(function(){
			$(".questionList").children(".question_box").eq(len).find(".nmb").text(len+1);
			len++;
		})
	}

	//上移
	function moveup(a){
		if($(a).closest(".kzjxx_iteam").attr("data-se")==1){
			alert("已经是最前了");
		}else{
			var moveup_html = $(a).closest(".kzjxx_iteam").html();
			var inputtext   = $(a).closest(".kzjxx_iteam").children("input").val();
			var title_itram = $(a).closest(".title_itram");                          //查找父级，让其子级重新排序
			$(a).closest(".kzjxx_iteam").prev().before('<div class="kzjxx_iteam" style="padding:5px 0;">'+moveup_html+'</div>');//前排拼接一个
			$(a).closest(".kzjxx_iteam").prev().prev().children("input").val(inputtext);//给上移的带上值
			$(a).closest(".kzjxx_iteam").remove();//拼接完移除后排
			var len = 1;
			for(len;len<=title_itram.children(".kzjxx_iteam").length;len++){//文本框顺序重排
				title_itram.children(".kzjxx_iteam").eq(len-1).attr("data-se",len);
			}
		}
	}
	//下移
	function movedown(a){
		
		if($(a).closest(".kzjxx_iteam").attr("data-se")>=$(a).closest(".title_itram").children(".kzjxx_iteam").length){//当等于索引长度时，不能下移
			alert("已经是最后了");
		}else{
			var moveup_html = $(a).closest(".kzjxx_iteam").html();
			var inputtext   = $(a).closest(".kzjxx_iteam").children("input").val();
			var title_itram = $(a).closest(".title_itram");                          //查找父级，让其子级重新排序
			$(a).closest(".kzjxx_iteam").next().after('<div class="kzjxx_iteam" style="padding:5px 0;">'+moveup_html+'</div>');//前排拼接一个
			$(a).closest(".kzjxx_iteam").next().next().children("input").val(inputtext);//给上移的带上值
			$(a).closest(".kzjxx_iteam").remove();//拼接完移除后排
			var len = 1;
			for(len;len<=title_itram.children(".kzjxx_iteam").length;len++){//文本框顺序重排
				title_itram.children(".kzjxx_iteam").eq(len-1).attr("data-se",len);
			}
		}
	}
	
	//复制
	function copyBox(a){
		//alert("aaa");
		var operation_boxC = $(a).parent(".operation").parent(".question_box").children(".operation_box");
		var result         = operation_boxC.attr("data-t");
		var question_box   = o(result);
		$(a).parent(".operation").parent(".question_box").after(question_box);//先根据类型生成一个问题
		var question_box_after = $(a).parent(".operation").parent(".question_box").next();                                        //复制的问题框
		var titleVal           = $(operation_boxC).parent(".question_box").children(".questionElement").find(".btwenzi").text();  //复制的标题
		question_box_after.find(".btwenzi").text(titleVal);
		
		
		if(result=="1"||result=="2"||result=="5"){//单选题||多选题||打分
			//遍历题目项目的文字
			var len = 1;
			operation_boxC.parent(".question_box").find(".questionElement").children("li").each(function() {
				//题目选项
				var inputVal = $(this).find("label").text();  //获取填写信息

				var mathid = Math.floor(Math.random()*100000);
				var setId  = inputVal+mathid;
				if(result=="1"){
					var li = '<li class="radio"><input name="a" data-se="'+len+'" id="'+setId+'" class="magic-radio" type="radio" value="'+inputVal+'"><label class="form-label" for="'+setId+'">' + inputVal + '</label></li>';
				}else if(result=="2"){
					var li = '<li class="checkbox"><input name="a" data-se="'+len+'" id="'+setId+'" class="magic-checkbox" type="checkbox" value="'+inputVal+'"><label class="form-label" for="'+setId+'">' + inputVal + '</label></li>';
				}else if(result=="5"){
					var li = '<li class="radio"><input name="a" data-se="'+len+'" id="'+setId+'" class="magic-radio" type="radio" value="'+inputVal+'"><label class="form-label" for="'+setId+'">' + inputVal + '分</label></li>';
				}
				question_box_after.find(".questionElement").append(li);
				len++;
			});
		}else if(result=="4"||result=="6"){//矩阵选择||矩阵评分
			
			
			var tr = '<tr>'
			var th = '';
			
			//复制th=================================================
			operation_boxC.parent(".question_box").find(".questionElement").children(".mytable").children("table")
			.children("thead").children("tr").children("th").each(function() {
				var thval  = $(this).text();
				    th    += '<th>'+thval+'</th>';
					
			})
			question_box_after.find("thead").append(tr+th);


			//复制td=================================================
			
			operation_boxC.parent(".question_box").find(".questionElement").children(".mytable").children("table")
			.children("tbody").children("tr").each(function() {
				var td  = '';
				var len = 0;
				var thval ;
				$(this).children("td").each(function() {
					if(len==0){
						 thval  = $(this).text();
						 td    += '<td>' +thval+ '</td>';
						 thval  = thval+Math.floor(Math.random()*100000);
					}else{
						var mathid   = thval;
						var mathid2  = Math.floor(Math.random()*100000);
						    td      += '<td><li class="radio"><input id="'+mathid2+'"  class="magic-radio"   name="'+mathid+'" type="radio" value=""><label class="form-label" for="'+mathid2+'"></label></li></td>';
					}
					len++;
				})
				question_box_after.find("tbody").append(tr+td);
				question_box_after.find(".mytable").removeClass("hidden");
			})
		
		
		}
		
		//判断是否有comments：
		if(operation_boxC.parent(".question_box").find(".mycomments").length>0){
			question_box_after.find(".questionElement").append('<div class="row mycomments"><label class="control-label">comments:</label><textarea  name="" cols="" rows="" class="form-control" ></textarea></div>');
		}
		//重新遍历问题序号
		var len = 0;
		$(".questionList").find(".question_box").each(function(){
			$(".questionList").children(".question_box").eq(len).find(".nmb").text(len+1);
			len++;
		})
	}

	
	
	//编辑
	function editBox(a){
		
		$(a).parent(".operation").css("display","none");
		var danxuanE       = $(".danxuan").html();                                                          //获取单选题的编辑框
		var duoxuanE       = $(".duoxuan").html();                                                          //多选
		var tiankongE      = $(".tiankong").html();                                                         //填空
		var juzhenXuanzheE = $(".juzhenXuanzhe").html();                                                    //矩阵选择
		var dafenE         = $(".dafen").html();                                                            //打分
		var juzhenpingE    = $(".juzhenping").html();                                                       //矩阵评分
		var operation_box  = $(a).parent(".operation").parent(".question_box").children(".operation_box");  //编辑器容器
		var datat          = operation_box.attr("data-t");
		                                           //获取属性值判断是什么题目		
		//问题元素
		var questionLiLen = $(a).parent(".operation").parent(".question_box").children(".questionElement").find("li").length;
		if(datat=="1"||datat=="2"||datat=="5"){//单选题||多选||打分
			if(datat=="1"){
				operation_box.show().html(danxuanE);
			}else if(datat=="2"){
				operation_box.show().html(duoxuanE);
			}else if(datat=="5"){
				operation_box.show().html(dafenE);
				$("[data-toggle='tooltip']").tooltip(); 
			}
			//模具已有选项个数
			var model_Len  = operation_box.find(".title_itram").children(".kzjxx_iteam").length;
			var model_Html = operation_box.find(".title_itram").children(".kzjxx_iteam").html();
			for(var i=model_Len;i<questionLiLen;i++){
				operation_box.find(".title_itram").append("<div class='kzjxx_iteam' data-se='' style='padding:5px 0;'>" + model_Html + "</div>");
			}
			//赋值文本框 
			//题目标题
			var titleVal = $(a).parent(".operation").parent(".question_box").children(".questionElement").find(".btwenzi").text();  //标题的值
			operation_box.find(".titleEdit").val(titleVal);
			//遍历编辑前所有的选项值
			var len = 0;
			$(a).parent(".operation").parent(".question_box").children(".questionElement").children("li").each(function(){
				var chooseVal = $(this).find("label").text();
				if(datat=="5"){
					chooseVal = chooseVal.substr(0,chooseVal.indexOf("分"));  //截取掉分字
				}
				operation_box.find(".title_itram").children(".kzjxx_iteam").eq(len).find(".input_wenbk").val(chooseVal);
				operation_box.find(".title_itram").children(".kzjxx_iteam").eq(len).attr("data-se",len+1);
				len++;
			})
		}else if(datat=="3"){//填空题
			operation_box.show().html(tiankongE);
			//赋值文本框 
			//题目标题
			var titleVal = $(a).parent(".operation").parent(".question_box").children(".questionElement").find(".btwenzi").text();  //标题的值
			operation_box.find(".titleEdit").val(titleVal);

		}else if(datat=="4"||datat=="6"){
			if(datat=="4"){
				operation_box.show().html(juzhenXuanzheE);
			}else if(datat=="6"){
				operation_box.show().html(juzhenpingE);
			}
			
			$("[data-toggle='tooltip']").tooltip(); 
			//赋值文本框 
			//题目标题
			var titleVal = $(a).parent(".operation").parent(".question_box").children(".questionElement").find(".btwenzi").text();  //标题的值
			operation_box.find(".titleEdit").val(titleVal);
			//选项总个数
			var questionLiLen = $(a).parent(".operation").parent(".question_box").children(".questionElement").find("th").length;
			//模具已有选项个数
			var model_Len  = operation_box.find(".secondtd").find(".title_itram").children(".kzjxx_iteam").length;
			var model_Html = operation_box.find(".secondtd").find(".title_itram").children(".kzjxx_iteam").html();
			for(var i=model_Len;i<questionLiLen-1;i++){
				operation_box.find(".secondtd").find(".title_itram").append("<div class='kzjxx_iteam' data-se='' style='padding:5px 0;'>" + model_Html + "</div>");

			}


			//左标题总个数
			var lefttitle = $(a).parent(".operation").parent(".question_box").children(".questionElement").find("tbody").find("tr").length;
			;
			//模具已有选项个数
			var model_title_len  = operation_box.find(".firsttd").find(".title_itram").children(".kzjxx_iteam").length;
			var model_title_html = operation_box.find(".firsttd").find(".title_itram").children(".kzjxx_iteam").html();
			
			for(var i=model_title_len;i<lefttitle;i++){
				operation_box.find(".firsttd").find(".title_itram").append("<div class='kzjxx_iteam' data-se='' style='padding:5px 0;'>" + model_title_html + "</div>");
			}
			
			var len = 0;
			//遍历编辑前所有的选项值
			$(a).parent(".operation").parent(".question_box").children(".questionElement").children(".mytable").children("table").children("thead").children("tr").children("th").each(function(){
				
				var thVal   = $(this).text();
				var data_se = $(this).attr("data-se");
				if(datat=="6"){
					thVal = thVal.substr(0,thVal.indexOf("分"));
				}
				
				operation_box.find(".secondtd").find(".title_itram").children(".kzjxx_iteam").eq(len-1).find(".input_wenbk").val(thVal);
				operation_box.find(".secondtd").find(".title_itram").children(".kzjxx_iteam").eq(len-1).attr("data-se",data_se);
				len++;
			})

			var juzhenQuestion = '';
			//遍历左标题
			len = 0;
			$(a).parent(".operation").parent(".question_box").children(".questionElement").children(".mytable").children("table").children("tbody").children("tr").each(function(){
				var thVal   = $(this).find('td').eq(0).text();
				var data_se = $(this).find('td').eq(0).attr("data-se");
				
				operation_box.find(".firsttd").find(".title_itram").children(".kzjxx_iteam").eq(len).find(".input_wenbk").val(thVal);
				operation_box.find(".firsttd").find(".title_itram").children(".kzjxx_iteam").eq(len).attr("data-se",data_se);
				len++;
				
			})
			operation_box.find(".left_question").val(juzhenQuestion);
		}
		$("[data-toggle='tooltip']").tooltip(); 

	}
	
	
	//添加选项  
	function addInput(a){
		var zjxx_html = $(a).prev(".title_itram").children(".kzjxx_iteam").html();
		$(a).prev(".title_itram").append("<div class='kzjxx_iteam' data-se='' style='padding:5px 0;'>" + zjxx_html + "</div>");
		var title_itram = $(a).prev(".title_itram");  //用于文本框顺序重排
		var len         = 1;
			for(len;len<=title_itram.children(".kzjxx_iteam").length;len++){//文本框顺序重排
				title_itram.children(".kzjxx_iteam").eq(len-1).attr("data-se",len);
			}
		$("[data-toggle='tooltip']").tooltip(); 
	}

	//删除一个选项  
	function deleteInput(a){
	//	$(a).parent(".kzjxx_iteam").remove();
		//获取编辑题目的个数
		var zuxxs_num = $(a).parent(".kzjxx_iteam").parent(".title_itram").children(".kzjxx_iteam").length;
		if(zuxxs_num > 1) {
			$(a).parent(".kzjxx_iteam").remove();
		} else {
			alert("手下留情");
		}
	}
	
	//取消编辑
	function cancelEdit(a){
		$(a).parent(".bjqxwc_box").parent(".editcss").parent(".operation_box").empty().hide();
		$(".question_box").css({
			"border": "1px solid #fff"
		});
		            
	};

	//完成编辑
	function finishEdit(a){
		
		var operation_box = $(a).parent(".bjqxwc_box").parent(".editcss").parent(".operation_box");  //编辑区
		var querstionType = operation_box.attr("data-t");                                            //获取题目类型
		//赋值文本框 
		//题目标题
		var titleVal = operation_box.find(".titleEdit").val();  //获取问题题目
		operation_box.parent(".question_box").children(".questionElement").find(".btwenzi").text(titleVal); //将修改过的问题题目展示

		operation_box.parent(".question_box").children(".questionElement").children(".mycomments").remove();

		if(querstionType=="1"||querstionType=="2"||querstionType=="5"){//单选题||多选题||打分
			var editLen     = operation_box.find(".title_itram").children(".kzjxx_iteam").length;                        //获取编辑选项的个数
			var questionLen = operation_box.parent(".question_box").children(".questionElement").children("li").length;  //题目选择的个数
			
			//删除选项（删除显示框的内容，除了标题）
			for(var i = questionLen-1; i >= 0; i--) {
				operation_box.parent(".question_box").children(".questionElement").children("li").eq(i).remove();
			}
			//遍历题目项目的文字
			var len = 1;
			operation_box.find(".title_itram").children(".kzjxx_iteam").each(function() {
				//题目选项
				var inputVal = $(this).find(".input_wenbk").val();  //获取填写信息
				var mathid   = Math.floor(Math.random()*100000);
				var setId    = inputVal+mathid;
				
				if(querstionType=="1"){//完成编辑（单选题）
					var li = '<li class="radio"><input name="a" id="'+setId+'" class="magic-radio" type="radio" value="'+inputVal+'"><label class="form-label" for="'+setId+'">' + inputVal + '</label></li>';
				}else if(querstionType=="2"){//完成编辑（多选题）
					var li = '<li class="checkbox"><input name="a" id="'+setId+'" class="magic-checkbox" type="checkbox" value="'+inputVal+'"><label class="form-label" for="'+setId+'">' + inputVal + '</label></li>';
				}else if(querstionType=="5"){//完成编辑（打分题）
					var li = '<li class="radio"><input name="a" id="'+setId+'" class="magic-radio" type="radio" value="'+inputVal+'"><label class="form-label" for="'+setId+'">' + inputVal + '分</label></li>';
				}
				operation_box.parent(".question_box").children(".questionElement").append(li);
				len++;
			});
			
		}else if(querstionType=="4"||querstionType=="6"){//矩阵选择||矩阵评分
			//alert("aa");
			operation_box.parent(".question_box").children(".questionElement").children(".mytable").removeClass("hidden");
			operation_box.parent(".question_box").children(".questionElement").find("table").children("tbody").empty();
			operation_box.parent(".question_box").children(".questionElement").find("table").children("thead").empty();
			var x_iteam = new Array();
			                                         
			var y_iteam = "";  //左标题

			operation_box.find(".firsttd").find(".title_itram").children(".kzjxx_iteam").each(function() {//获取左标题并拼接
				var input_wenbk  = $(this).find(".input_wenbk").val();  //获取填写信息
				    y_iteam     += "\n"+input_wenbk;
				
			});
			operation_box.find(".secondtd").find(".title_itram").children(".kzjxx_iteam").each(function() {//获取选项，并封装集合
				var input_wenbk = $(this).find(".input_wenbk").val();  //获取填写信息
				x_iteam.push({name:input_wenbk})//塞入集合里
			});
			
			var y_iteams = y_iteam.split("\n");  //分割成数组
			
			for(var item=0; item< y_iteams.length;item++ ){//遍历行
				var tr      = '<tr>'
				var td      = '';
				    td     += '<td>' + y_iteams[item] + '</td>';
				var th      = '';
				    th     += '<th>'+y_iteams[item]+'</th>';
				var mathid  = Math.floor(Math.random()*100000);
				    mathid  = y_iteams[item]+mathid;
				for(var i = 0; i < x_iteam.length; i++) { //遍历列
					if(item!=0){
						var mathid2  = Math.floor(Math.random()*100000);
						    td      += '<td><li class="radio"><input id="'+mathid2+'"  class="magic-radio"   name="'+mathid+'" type="radio" value=""><label class="form-label" for="'+mathid2+'"></label></li></td>';
					}else{ //选项名
						if(querstionType=="6"){
							th += '<th>'+x_iteam[i].name+'分</th>';
						}else if(querstionType=="4"){
							th += '<th>'+x_iteam[i].name+'</th>';
						}
					}
				}
				if(item!=0){
					operation_box.parent(".question_box").children(".questionElement").find(".mytable").children("table").children("tbody").append(tr+td);
				}else{
					operation_box.parent(".question_box").children(".questionElement").find(".mytable").children("table").children("thead").append(tr+th);
				}
				
			}
			
		}

		//判断是否有comments
		operation_box.find(".needcomments").find(".radio").children("input").each(function() {
			if($(this).get(0).checked){
				var needcomments = $(this).val();
				if(needcomments==1){
					operation_box.parent(".question_box").children(".questionElement").append('<div class="row mycomments"><label class="control-label">comments:</label><textarea  name="" cols="" rows="" class="form-control" ></textarea></div>');
				}
			}
		})

		//清除     
		$(a).parent(".bjqxwc_box").parent(".editcss").parent(".operation_box").empty().hide();
		$(".question_box").css({
			"border": "1px solid #fff"
		});
	}

	