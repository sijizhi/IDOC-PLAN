

$(document).ready(function(e) {
    var num = 0;
//=====拖拽  start=============================
    //单选题
    $("#addRadio").draggable({
        cancel           : "",
        containment      : "#questionList",
        connectToSortable: "#questionList",
        helper           : "clone",
        revert           : "invalid",
        cursor           : "crosshair",
        distance         : "15",
        opacity          : "0.8",
        scroll           : "true",
        stop             : function(event,ui){
            var question_box = o(1);
            for(var inputVal=1;inputVal<3;inputVal++){
                var mathid = Math.floor(Math.random()*100000);
                var li     = '<li class="radio"><input name="a" id="'+mathid+'" data-se="'+inputVal+'" class="magic-radio" type="radio" value="'+mathid+'"><label class="form-label" for="'+mathid+'">选项' + inputVal + '</label></li>';
                question_box.children(".questionElement").append(li);
            }
            //event.toElement.outerHTML = '<ul class="question_box panel clearboth"  style="min-height:120px;">'+question_box.html()+'</ul>';
            event.originalEvent.target.outerHTML = '<ul class="question_box panel clearboth"  style="min-height:120px;">'+question_box.html()+'</ul>';
            console.log(event);
			setTimeout(function(){
				var width = ($(document.body).width());
			if(width>=1572){
				$("#container.mainnav-sm #mainnav-container, #container.mainnav-sm #navbar .navbar-brand").css({
					"width":"223px"
				})
                if (num > 0) {
                    $(".question_box").css({
                        "width": width - 223 - 14 + "px",
                        "margin-left": "11.4%"
                    })
             
                } else {
                    $(".question_box").css({
                        "width": width - 223 - 14 + "px",
                        
                    })
                }
				$("#mainnav-menu").css({
					"margin-top":"10%"
				})
			}
			if(width>=769&&width<=1571){
				$("#container.mainnav-sm #mainnav-container, #container.mainnav-sm #navbar .navbar-brand").css({
					"width":"120px"
				})
				$(".question_box").css({
					"width":width-140+"px",
					"margin-left":"8%"
				})
			}
			if(width<=767){
				$(".question_box").css({
					"width":width-12+"px",
					
				})
			}
			},1);
            //鼠标移动时
            
            $("#questionList .question_box").hover(function() {
                $(this).children(".operation").css("display","block");
                $(this).css({
                    "border": "2px solid #0099ff",
                    "border-radius":"10px",
                });
            }, function() {
                $(this).css({
                    "border": "2px solid #fff"  //不在域内的颜色
                });
                $(this).children(".operation").css("display","none");
            });
            var len = 0;
            $(".questionList").find(".question_box").each(function(){
                $(".questionList").children(".question_box").eq(len).find(".nmb").text(len+1);
                len++;
            })
    }
    });


    //多选题
    $("#addCheckbox").draggable({
        cancel           : "",
        containment      : "#questionList",
        connectToSortable: "#questionList",
        helper           : "clone",
        revert           : "invalid",
        cursor           : "crosshair",
        distance         : "15",
        opacity          : "0.8",
        scroll           : "true",
        stop             : function(event,ui){
            var question_box = o(2);
            for(var inputVal=1;inputVal<3;inputVal++){
                var mathid = Math.floor(Math.random()*100000);
                var li     = '<li class="checkbox"><input name="a" id="'+mathid+'" data-se="'+inputVal+'" class="magic-checkbox" type="checkbox" value="'+mathid+'"><label class="form-label" for="'+mathid+'">选项' + inputVal + '</label></li>';
                question_box.children(".questionElement").append(li);
            }
            event.toElement.outerHTML = '<ul class="question_box panel clearboth"  style="min-height:120px;">'+question_box.html()+'</ul>';
			setTimeout(function(){
				var width = ($(document.body).width());
			if(width>=1572){
				$("#container.mainnav-sm #mainnav-container, #container.mainnav-sm #navbar .navbar-brand").css({
					"width":"223px"
				})
                if (num > 0) {
                    $(".question_box").css({
                        "width": width - 223 - 14 + "px",
                        "margin-left": "11.4%"
                    })
                    console.log("aa");
                } else {
                    $(".question_box").css({
                        "width": width - 223 - 14 + "px",
                        
                    })
                }
				$("#mainnav-menu").css({
					"margin-top":"10%"
				})
			}
			if(width>=769&&width<=1571){
				$("#container.mainnav-sm #mainnav-container, #container.mainnav-sm #navbar .navbar-brand").css({
					"width":"120px"
				})
				$(".question_box").css({
					"width":width-140+"px",
					"margin-left":"8%"
				})
			}
			if(width<=767){
				$(".question_box").css({
					"width":width-12+"px",
					
				})
			}
			},1);
            //鼠标移动时
            $("#questionList .question_box").hover(function() {
                $(this).children(".operation").css("display","block");
                $(this).css({
                    "border": "2px solid #0099ff",
                    "border-radius":"10px"
                });
            }, function() {
                $(this).css({
                    "border": "2px solid #fff"  //不在域内的颜色
                });
                $(this).children(".operation").css("display","none");
            });
            var len = 0;
            $(".questionList").find(".question_box").each(function(){
                $(".questionList").children(".question_box").eq(len).find(".nmb").text(len+1);
                len++;
            })
        }
    });

      //打分题
      $("#addDafen").draggable({
        cancel           : "",
        containment      : "#questionList",
        connectToSortable: "#questionList",
        helper           : "clone",
        revert           : "invalid",
        cursor           : "crosshair",
        distance         : "15",
        opacity          : "0.8",
        scroll           : "true",
        stop             : function(event,ui){
            var question_box = o(5);
            for(var inputVal=1;inputVal<3;inputVal++){
                var mathid = Math.floor(Math.random()*100000);
                var li     = '<li class="radio"><input name="a" id="'+mathid+'" data-se="'+inputVal+'" class="magic-radio" type="radio" value="'+mathid+'"><label class="form-label" for="'+mathid+'">' + inputVal + '分</label></li>';
                question_box.children(".questionElement").append(li);
            }
            event.toElement.outerHTML = '<ul class="question_box panel clearboth"  style="min-height:120px;">'+question_box.html()+'</ul>';
			setTimeout(function(){
				var width = ($(document.body).width());
			if(width>=1572){
				$("#container.mainnav-sm #mainnav-container, #container.mainnav-sm #navbar .navbar-brand").css({
					"width":"223px"
				})
                if (num > 0) {
                    $(".question_box").css({
                        "width": width - 223 - 14 + "px",
                        "margin-left": "11.4%"
                    })
                    console.log("aa");
                } else {
                    $(".question_box").css({
                        "width": width - 223 - 14 + "px",
                        
                    })
                }
				$("#mainnav-menu").css({
					"margin-top":"10%"
				})
			}
			if(width>=769&&width<=1571){
				$("#container.mainnav-sm #mainnav-container, #container.mainnav-sm #navbar .navbar-brand").css({
					"width":"120px"
				})
				$(".question_box").css({
					"width":width-140+"px",
					"margin-left":"8%"
				})
			}
			if(width<=767){
				$(".question_box").css({
					"width":width-12+"px",
					
				})
			}
			},1);
            //鼠标移动时
            $("#questionList .question_box").hover(function() {
                $(this).children(".operation").css("display","block");
                $(this).css({
                    "border": "2px solid #0099ff",
                    "border-radius":"10px"
                });
            }, function() {
                $(this).css({
                    "border": "2px solid #fff"  //不在域内的颜色
                });
                $(this).children(".operation").css("display","none");
            });
            var len = 0;
            $(".questionList").find(".question_box").each(function(){
                $(".questionList").children(".question_box").eq(len).find(".nmb").text(len+1);
                len++;
            })
        }
    });

    //填空题
    $("#addTian").draggable({
        cancel           : "",
        containment      : "#questionList",
        connectToSortable: "#questionList",
        helper           : "clone",
        revert           : "invalid",
        cursor           : "crosshair",
        distance         : "15",
        opacity          : "0.8",
        scroll           : "true",
        stop             : function(event,ui){
            var question_box = o(3);
            
            event.toElement.outerHTML = '<ul class="question_box panel clearboth"  style="min-height:120px;">'+question_box.html()+'</ul>';
			setTimeout(function(){
				var width = ($(document.body).width());
			if(width>=1572){
				$("#container.mainnav-sm #mainnav-container, #container.mainnav-sm #navbar .navbar-brand").css({
					"width":"223px"
				})
                if (num > 0) {
                    $(".question_box").css({
                        "width": width - 223 - 14 + "px",
                        "margin-left": "11.4%"
                    })
                    console.log("aa");
                } else {
                    $(".question_box").css({
                        "width": width - 223 - 14 + "px",
                        
                    })
                }
				$("#mainnav-menu").css({
					"margin-top":"10%"
				})
			}
			if(width>=769&&width<=1571){
				$("#container.mainnav-sm #mainnav-container, #container.mainnav-sm #navbar .navbar-brand").css({
					"width":"120px"
				})
				$(".question_box").css({
					"width":width-140+"px",
					"margin-left":"8%"
				})
			}
			if(width<=767){
				$(".question_box").css({
					"width":width-12+"px",
					
				})
			}
			},1);
            //鼠标移动时
            $("#questionList .question_box").hover(function() {
                $(this).children(".operation").css("display","block");
                $(this).css({
                    "border": "2px solid #0099ff",
                    "border-radius":"10px"
                });
            }, function() {
                $(this).css({
                    "border": "2px solid #fff"  //不在域内的颜色
                });
                $(this).children(".operation").css("display","none");
            });
            var len = 0;
            $(".questionList").find(".question_box").each(function(){
                $(".questionList").children(".question_box").eq(len).find(".nmb").text(len+1);
                len++;
            })
        }
    });
    

      //矩阵选择
      $("#addJuChoose").draggable({
        cancel           : "",
        containment      : "#questionList",
        connectToSortable: "#questionList",
        helper           : "clone",
        revert           : "invalid",
        cursor           : "crosshair",
        distance         : "15",
        opacity          : "0.8",
        scroll           : "true",
        stop             : function(event,ui){
            var question_box = o(4);
            for(var item=0; item<3;item++ ){//遍历行
                var tr      = '<tr>'
                var td      = '';
                    td     += '<td data-se="'+item+'">问题' +item+ '</td>';
                var th      = '';
                    th     += '<th data-se="0"></th>';
                var mathid  = Math.floor(Math.random()*100000);
                for(var i = 1; i < 4; i++) { //遍历列
                    
                    if(item!=0){
                        var mathid2  = Math.floor(Math.random()*100000);
                            td      += '<td><li class="radio"><input id="'+mathid2+'"   class="magic-radio"   name="'+mathid+'" type="radio" value=""><label class="form-label" for="'+mathid2+'"></label></li></td>';
                    }else{ //选项名
                         th += '<th data-se="'+i+'">选项'+i+'</th>';
                    }
                }
                if(item!=0){
                    question_box.children(".questionElement").find(".mytable").children("table").children("tbody").append(tr+td);
                }else{
                    question_box.children(".questionElement").find(".mytable").children("table").children("thead").append(tr+th);
                }
                question_box.find(".mytable").removeClass("hidden");
                
            }

            event.toElement.outerHTML = '<ul class="question_box panel clearboth"  style="min-height:120px;">'+question_box.html()+'</ul>';
			setTimeout(function(){
				var width = ($(document.body).width());
			if(width>=1572){
				$("#container.mainnav-sm #mainnav-container, #container.mainnav-sm #navbar .navbar-brand").css({
					"width":"223px"
				})
                if (num > 0) {
                    $(".question_box").css({
                        "width": width - 223 - 14 + "px",
                        "margin-left": "11.4%"
                    })
                    console.log("aa");
                } else {
                    $(".question_box").css({
                        "width": width - 223 - 14 + "px",
                        
                    })
                }
				$("#mainnav-menu").css({
					"margin-top":"10%"
				})
			}
			if(width>=769&&width<=1571){
				$("#container.mainnav-sm #mainnav-container, #container.mainnav-sm #navbar .navbar-brand").css({
					"width":"120px"
				})
				$(".question_box").css({
					"width":width-140+"px",
					"margin-left":"8%"
				})
			}
			if(width<=767){
				$(".question_box").css({
					"width":width-12+"px",
					
				})
			}
			},1);
            //鼠标移动时
            $("#questionList .question_box").hover(function() {
                $(this).children(".operation").css("display","block");
                $(this).css({
                    "border": "2px solid #0099ff",
                    "border-radius":"10px"
                });
            }, function() {
                $(this).css({
                    "border": "2px solid #fff"  //不在域内的颜色
                });
                $(this).children(".operation").css("display","none");
            });
            var len = 0;
            $(".questionList").find(".question_box").each(function(){
                $(".questionList").children(".question_box").eq(len).find(".nmb").text(len+1);
                len++;
            })
        }
    });


    //矩阵评分
    $("#addJuPing").draggable({
        cancel           : "",
        containment      : "#questionList",
        connectToSortable: "#questionList",
        helper           : "clone",
        revert           : "invalid",
        cursor           : "crosshair",
        distance         : "15",
        opacity          : "0.8",
        scroll           : "true",
        stop             : function(event,ui){
            var question_box = o(4);
            for(var item=0; item<3;item++ ){//遍历行
                var tr      = '<tr>'
                var td      = '';
                    td     += '<td data-se="'+item+'">问题' +item+ '</td>';
                var th      = '';
                    th     += '<th data-se="0"></th>';
                var mathid  = Math.floor(Math.random()*100000);
                for(var i = 1; i < 4; i++) { //遍历列
                    
                    if(item!=0){
                        var mathid2  = Math.floor(Math.random()*100000);
                            td      += '<td><li class="radio"><input id="'+mathid2+'"   class="magic-radio"   name="'+mathid+'" type="radio" value=""><label class="form-label" for="'+mathid2+'"></label></li></td>';
                    }else{ //选项名
                         th += '<th data-se="'+i+'">'+i+'分</th>';
                    }
                }
                if(item!=0){
                    question_box.children(".questionElement").find(".mytable").children("table").children("tbody").append(tr+td);
                }else{
                    question_box.children(".questionElement").find(".mytable").children("table").children("thead").append(tr+th);
                }
                question_box.find(".mytable").removeClass("hidden");
                
            }

            event.toElement.outerHTML = '<ul class="question_box panel clearboth"  style="min-height:120px;">'+question_box.html()+'</ul>';
			setTimeout(function(){
				var width = ($(document.body).width());
			if(width>=1572){
				$("#container.mainnav-sm #mainnav-container, #container.mainnav-sm #navbar .navbar-brand").css({
					"width":"223px"
				})
                if (num > 0) {
                    $(".question_box").css({
                        "width": width - 223 - 14 + "px",
                        "margin-left": "11.4%"
                    })
                    console.log("aa");
                } else {
                    $(".question_box").css({
                        "width": width - 223 - 14 + "px",
                        
                    })
                }
				$("#mainnav-menu").css({
					"margin-top":"10%"
				})
			}
			if(width>=769&&width<=1571){
				$("#container.mainnav-sm #mainnav-container, #container.mainnav-sm #navbar .navbar-brand").css({
					"width":"120px"
				})
				$(".question_box").css({
					"width":width-140+"px",
					"margin-left":"8%"
				})
			}
			if(width<=767){
				$(".question_box").css({
					"width":width-12+"px",
					
				})
			}
			},1);
            //鼠标移动时
            $("#questionList .question_box").hover(function() {
                $(this).children(".operation").css("display","block");
                $(this).css({
                    "border": "2px solid #0099ff",
                    "border-radius":"10px"
                });
            }, function() {
                $(this).css({
                    "border": "2px solid #fff"  //不在域内的颜色
                });
                $(this).children(".operation").css("display","none");
            });
            var len = 0;
            $(".questionList").find(".question_box").each(function(){
                $(".questionList").children(".question_box").eq(len).find(".nmb").text(len+1);
                len++;
            })
        }
    });
    //==========================拖拽  end=============================

})

